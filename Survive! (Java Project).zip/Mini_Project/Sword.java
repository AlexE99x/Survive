public class Sword extends Item {
    public Sword(String name, int damage_inflict){
        super(name, damage_inflict);
    }
}