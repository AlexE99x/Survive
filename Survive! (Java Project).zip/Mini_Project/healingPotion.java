public class healingPotion extends Potion {

    public healingPotion(int health_impact, int contents){
        super("Healing Potion", health_impact, contents);
    }
   
}