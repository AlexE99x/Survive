public class Zombie_Sword extends Sword {

    public Zombie_Sword(int damage_inflict){
        super("Zombie Sword", damage_inflict);
    }

}