public class Shield extends Item {

    public Shield(String name, int damage_inflict){
        super(name, damage_inflict);
    }

}