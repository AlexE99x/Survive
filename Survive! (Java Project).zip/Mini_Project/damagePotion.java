public class damagePotion extends Potion {
    
   public damagePotion(int health_impact, int contents){
        super("Damage Potion", health_impact, contents);
   }
}