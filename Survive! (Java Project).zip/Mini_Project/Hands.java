public class Hands extends Item {

    public Hands(int damage_inflict) {
        super("Hands", damage_inflict);
    }
}